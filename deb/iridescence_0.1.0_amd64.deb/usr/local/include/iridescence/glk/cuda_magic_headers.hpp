#ifndef GLK_CUDA_MAGIC_HEADERS_HPP
#define GLK_CUDA_MAGIC_HEADERS_HPP

// the following headers are necesarry to avoid incomplete class errros on nvcc
#include <boost/utility/in_place_factory.hpp>
#include <boost/utility/typed_in_place_factory.hpp>

#endif